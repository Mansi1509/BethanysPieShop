﻿using System.Data.Entity;
using System.Linq;
using System.Net;
using Carental.Models;

using ICSharpCode.NRefactory.CSharp;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Carental.Controllers
{
    public class PersonController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: Person
        public ActionResult Index()
        {
            if(Roles.IsUserInRole("admin"))
            {
                var person = db.Person.Include(p => p.User);
                return View(person.ToList());
            }
            else
            {
                return View();
            }
                
        }

        // GET: Person/Details/5
        public ActionResult Details(int? id)
        {
           

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            if ((id == (int)Session["iduser"]) || (Roles.IsUserInRole("admin")))
            {
                
                PersonModels personModels = db.Person.Find(id);
                string[] roleuser = Roles.GetRolesForUser(personModels.Email); 
                ViewBag.role = roleuser[0];
                return View(personModels);
            }
            return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        }

        // GET: Person/Create
        public ActionResult Create()
        {
            ViewBag.ApplicationUserId = new SelectList(db.Person, "Id", "Email");
            return View();
        }

       
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "IdPerson,Email,Name,Nickname,Driving_habits,Driver_experience,ApplicationUserId")] PersonModels personModels)
        {
            if (ModelState.IsValid)
            {
                db.Person.Add(personModels);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.ApplicationUserId = new SelectList(db.Person, "Id", "Email", personModels.ApplicationUserId);
            return View(personModels);
        }

        // GET: Person/Edit/5
        public ActionResult Edit(int? id)
        {

                      
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PersonModels personModels = db.Person.Find(id);
            if (personModels == null)
            {
                return HttpNotFound();
            }
            ViewBag.ApplicationUserId = new SelectList(db.Person, "Id", "Email", personModels.ApplicationUserId);
            return View(personModels);
        }

        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "IdPerson,Email,Name,Nickname,Driving_habits,Driver_experience,ApplicationUserId")] PersonModels personModels)
        {
            if (ModelState.IsValid)
            {
                db.Entry(personModels).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.ApplicationUserId = new SelectList(db.Person, "Id", "Email", personModels.ApplicationUserId);
            return View(personModels);
        }

        // GET: Person/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PersonModels personModels = db.Person.Find(id);
            if (personModels == null)
            {
                return HttpNotFound();
            }
            return View(personModels);
        }

        // POST: Person/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            PersonModels personModels = db.Person.Find(id);
            db.Person.Remove(personModels);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
